RUWA — THREE RECOVERED MALE DENTIST PORTRAITS

These three portrait crops were recovered from the previously generated RUWA dental-team images in the user's prior conversation. They are supplied as existing images, not newly generated images.

Files:
- ruwa-team-doctor-01.png — 545 x 681 px
- ruwa-team-doctor-02.png — 560 x 700 px
- ruwa-team-doctor-03.png — 560 x 700 px (selected centered crop)

All three portraits depict adult men only. They are fictional AI-generated visual assets and must be disclosed as illustrative; do not invent real names, credentials, specialties, licences, employment, or clinical experience for the depicted people.

Use these exact PNG files as source assets. Preserve the original pixels and aspect ratio. For web delivery, you may create WebP derivatives at quality 90–94, but keep the PNG originals in the repository or archive. Do not regenerate, redraw, face-swap, alter facial features, or add any new people.
